

## 네이버 영화 평점 기준 영화의 평점 변화 확인하기


```python
from bs4 import BeautifulSoup  
import pandas as pd
```


```python
from urllib.request import urlopen

url_base = "http://movie.naver.com/"
url_syb = "movie/sdb/rank/rmovie.nhn?sel=cur&date=20170804"

page = urlopen(url_base+url_syb)

soup = BeautifulSoup(page, "html.parser")
soup
```




    
    <!DOCTYPE html>
    
    <html lang="ko">
    <head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"/>
    <meta content="http://imgmovie.naver.com/today/naverme/naverme_profile.jpg" property="me2:image">
    <meta content="네이버영화 " property="me2:post_tag">
    <meta content="네이버영화" property="me2:category1"/>
    <meta content="" property="me2:category2"/>
    <meta content="랭킹 : 네이버 영화" property="og:title"/>
    <meta content="영화, 영화인, 예매, 박스오피스 랭킹 정보 제공" property="og:description"/>
    <meta content="article" property="og:type"/>
    <meta content="https://movie.naver.com/movie/sdb/rank/rmovie.nhn?sel=cur&amp;date=20170804" property="og:url"/>
    <meta content="http://static.naver.net/m/movie/icons/OG_270_270.png" property="og:image"/><!-- http://static.naver.net/m/movie/im/navermovie.jpg -->
    <meta content="http://imgmovie.naver.com/today/naverme/naverme_profile.jpg" property="og:article:thumbnailUrl"/>
    <meta content="네이버 영화" property="og:article:author"/>
    <meta content="https://movie.naver.com/" property="og:article:author:url"/>
    <link href="https://ssl.pstatic.net/static/m/movie/icons/naver_movie_favicon.ico" rel="shortcut icon" type="image/x-icon"/>
    <title>랭킹 : 네이버 영화</title>
    <link href="/common/css/movie_tablet.css?20181227143456" rel="stylesheet" type="text/css"/>
    <link href="/common/css/common.css?20181227143456" rel="stylesheet" type="text/css"/>
    <link href="/common/css/layout.css?20181227143456" rel="stylesheet" type="text/css"/>
    <link href="/common/css/old_default.css?20181227143456" rel="stylesheet" type="text/css"/>
    <link href="/common/css/old_layout.css?20181227143456" rel="stylesheet" type="text/css"/>
    <link href="/common/css/old_common.css?20181227143456" rel="stylesheet" type="text/css"/>
    <link href="/common/css/old_super_db.css?20181227143456" rel="stylesheet" type="text/css"/>
    <script src="/common/js/default-min.js" type="text/javascript"></script>
    </meta></meta></head>
    <body>
    <div class="fix" id="wrap">
    <!-- GNB -->
    <script type="text/javascript">
    function delayed_submit(object) {
    	if (navigator.userAgent.indexOf('MSIE') == -1) {
    		var b = c = new Date();
          	while ((b.getTime() - c.getTime()) < 100) {
    			b = new Date();
          	}
    		//window.setTimeout(function() {object.submit(); console.log('s');}, 300);
    	} 
    }
    var gnb_service = 'movie';
    var gnb_logout = 'http://movie.naver.com/movie/sdb/rank/rmovie.nhn%3Fsel%3Dcur%26date%3D20170804';
    var gnb_template = "gnb_quirks_euckr"; /* https://ssl.pstatic.net/static.gn/templates/gnb_utf8.nhn */
    var gnb_brightness=3;
    var gnb_response = true;
    </script>
    <a name="gnb_top"></a>
    <!-- skip navigation -->
    <div id="u_skip">
    <a href="#header" onclick="document.getElementById('header').tabIndex=-1;document.getElementById('header').focus();return false;"><span>메인 메뉴로 바로가기</span></a>
    <a href="#content" id="gnb_goContent" onclick="document.getElementById('content').tabIndex=-1;document.getElementById('content').focus();return false;"><span>본문으로 바로가기</span></a>
    </div>
    <!-- //skip navigation -->
    <!-- GNB -->
    <div class="gnb_container">
    <div class="gnb_content">
    <div class="gnb_box">
    <div class="gnb_wrap">
    <div id="gnb" onload="javascript:getGNB();">
    <script charset="utf-8" src="https://ssl.pstatic.net/static.gn/templates/gnb_utf8.nhn" type="text/javascript"></script>
    </div>
    </div>
    <!-- 검색창 -->
    <form action="/movie/search/result.nhn" id="jSearchForm" method="get" style="margin:0;display:none;">
    <input maxlength="100" name="query" title="영화검색" type="text"/>
    <input name="section" type="hidden" value="all"/>
    </form>
    <fieldset class="srch_area" id="jSearchArea">
    <legend><span class="blind">영화검색 영역</span></legend>
    <div class="srch_field_on _view">
    <span class="ipt_srch">
    <label for="ipt_tx_srch" id="search_placeholder">영화검색</label>
    <input accesskey="s" autocomplete="off" class="ipt_tx_srch" id="ipt_tx_srch" maxlength="100" name="query" style="ime-mode:active;" type="text"/>
    <span class="align"></span>
    <span class="auto_tx"><a href="#" title="자동완성 펼치기"><img alt="자동완성 펼치기" height="4" src="https://ssl.pstatic.net/static/movie/2012/06/srch_arrow_down.gif" title="자동완성 펼치기" width="7"/></a></span>
    </span>
    <button class="btn_srch" onclick="clickcr(this, 'GNB.search', '', '', event); delayed_submit(this);" title="검색" type="submit"><span class="blind">검색</span></button>
    <!-- 자동 완성 영역임 #autocomplate_template-->
    </div>
    </fieldset>
    <!-- //검색창 -->
    </div>
    </div>
    </div>
    <!-- //GNB -->
    <!-- nClicks -->
    <script type="text/javascript">var nsc = "movie.sdb";</script>
    <script src="/common/js/clickcr.js" type="text/javascript"></script>
    <!-- // nClicks -->
    <!-- //GNB -->
    <!-- LNB -->
    <!-- header -->
    <div id="header">
    <h1 class="svc_name">
    <a class="ci_logo" href="http://www.naver.com/" id="lnb_gonaver" onclick="clickcr(this, 'LNB.naver', '', '', event);" title="naver로 바로가기"><img alt="NAVER" height="13" src="https://ssl.pstatic.net/static/movie/2013/07/logo_ci.png" width="62"/></a>
    <a class="svc_logo" href="/" onclick="clickcr(this, 'LNB.movie', '', '', event);" title="영화서비스홈으로 바로가기"><img alt="영화" height="19" src="https://ssl.pstatic.net/static/movie/2012/06/logo_svc.png" width="34"/></a>
    </h1>
    <div class="scrollbar scrollbar-noscript" id="scrollbar">
    <div class="scrollbar-box">
    <div class="scrollbar-content">
    <div class="in_scroll">
    <ul class="navi">
    <li>
    <a class="menu01" href="/" onclick="clickcr(this, 'LNB.home', '', '', event);" title="영화홈"><strong>영화홈</strong></a>
    </li>
    <li>
    <a class="menu02" href="/movie/running/current.nhn" onclick="clickcr(this, 'LNB.movies', '', '', event);" title="상영작·예정작"><strong>상영작·예정작</strong></a>
    <ul class="navi_sub" style="display:none">
    <li><a class="sub2_1" href="/movie/running/current.nhn" onclick="clickcr(this, 'LNB.now', '', '', event);" title="현재 상영영화"><em>현재 상영영화</em></a></li>
    <li><a class="sub2_2" href="/movie/running/premovie.nhn" onclick="clickcr(this, 'LNB.soon', '', '', event);" title="개봉 예정영화"><em>개봉 예정영화</em></a></li>
    <li><a class="sub2_3" href="/movie/running/weekendmovie.nhn" onclick="clickcr(this, 'LNB.guide', '', '', event);" title="TV/DVD 영화"><em>TV/DVD 영화</em></a></li>
    <li><a class="sub2_4" href="/movie/running/movieclip.nhn" onclick="clickcr(this, 'LNB.tailer', '', '', event);" title="예고편"><em>예고편</em></a></li>
    <!-- li><a href="/movie/preview/special.nhn" title="네이버 스페셜" class="sub1_7" onclick="clickcr(this, 'LNB.special', '', '', event);"><em>네이버 스페셜</em></a></li-->
    </ul>
    </li>
    <li>
    <a class="menu03_on" href="/movie/sdb/rank/rmovie.nhn" onclick="clickcr(this, 'LNB.db', '', '', event);" title="영화랭킹"><strong>영화랭킹</strong></a>
    <ul class="navi_sub" style="display:block">
    <li><a class="sub3_1_on" href="/movie/sdb/rank/rmovie.nhn" onclick="clickcr(this, 'LNB.rank', '', '', event);" title="랭킹"><em>랭킹</em></a></li>
    <li><a class="sub3_2" href="/movie/sdb/browsing/bmovie_nation.nhn" onclick="clickcr(this, 'LNB.dir', '', '', event);" title="디렉토리"><em>디렉토리</em></a></li>
    </ul>
    </li>
    <li>
    <a class="menu05" href="/movie/bi/mi/reserve.nhn" onclick="clickcr(this, 'LNB.ticket', '', '', event);" title="예매"><strong>예매</strong></a>
    <ul class="navi_sub" style="display:none">
    <li><a class="sub5_1" href="http://ticket.movie.naver.com/Ticket/Reserve.aspx" onclick="clickcr(this, 'LNB.buy', '', '', event);" title="예매하기"><em>예매하기</em></a></li>
    <li><a class="sub5_2" href="http://ticket.movie.naver.com/Order/OrderList.aspx" onclick="clickcr(this, 'LNB.check', '', '', event);" title="예매확인·취소"><em>예매확인·취소</em></a></li>
    <li><a class="sub5_3" href="http://ticket.movie.naver.com/Coupon/Ticket.aspx" onclick="clickcr(this, 'LNB.disticket', '', '', event);" title="예매권·할인권 등록"><em>예매권·할인권 등록</em></a></li>
    <li><a class="sub5_4" href="http://ticket.movie.naver.com/Discount/DiscountCard.aspx" onclick="clickcr(this, 'LNB.discard', '', '', event);" title="할인카드안내·등록"><em>할인카드안내·등록</em></a></li>
    <li><a class="sub5_5" href="http://help.naver.com/ops/step2/faq.nhn?parentId=77&amp;depth=2" onclick="clickcr(this, 'LNB.service', '', '', event);" target="_blank" title="이용안내"><em>이용안내</em></a></li>
    </ul>
    </li>
    <li>
    <a class="menu07" href="/movie/point/af/list.nhn" onclick="clickcr(this, 'LNB.comm', '', '', event);" title="평점·리뷰"><strong>평점·리뷰</strong></a>
    <ul class="navi_sub" style="display:none">
    <li><a class="sub7_1" href="/movie/point/af/list.nhn" onclick="clickcr(this, 'LNB.rating', '', '', event);" title="네티즌 평점"><em>네티즌 평점</em></a></li>
    <li><a class="sub7_2" href="/movie/board/review/list.nhn" onclick="clickcr(this, 'LNB.review', '', '', event);" title="네티즌 리뷰"><em>네티즌 리뷰</em></a></li>
    <li><a class="sub7_3" href="/movie/poll/naver/list.nhn" onclick="clickcr(this, 'LNB.poll', '', '', event);" title="폴 매니아"><em>폴 매니아</em></a></li>
    </ul>
    </li>
    <li>
    <a class="menu08" href="http://nstore.naver.com/movie/home.nhn" onclick="clickcr(this, 'LNB.download', '', '', event);" target="_blank" title="다운로드"><strong>다운로드</strong></a>
    </li>
    <li class="nav_indi">
    <a href="http://tv.naver.com/indiecinema" target="_blank" title="인디극장 UP"><strong>인디극장 UP</strong></a><!-- N=a:LNB.indie -->
    </li>
    </ul>
    <!-- div class="view_mode">
    							<a href="#" title="" class="normal_on"><em>1단 보기</em></a>
    							<a href="#" title="" class="wide_off"><em>2단 보기</em></a>
    						</div -->
    </div>
    </div>
    </div>
    <div class="scrollbar-v">
    <div class="scrollbar-button-up"></div>
    <div class="scrollbar-track">
    <div class="scrollbar-thumb"></div>
    </div>
    <div class="scrollbar-button-down"></div>
    </div>
    </div>
    </div>
    <!-- //header -->
    <!-- //LNB -->
    <div id="container">
    <!-- content -->
    <div id="content">
    <div class="article">
    <div class="old_layout old_super_db">
    <h3 class="h_db_rank"><strong class="blind">랭킹</strong></h3>
    <ul class="tab_db_rank">
    <li><a class="db_tab01_on" href="/movie/sdb/rank/rmovie.nhn" title="영화"><em>영화</em></a></li>
    <li><a class="db_tab02" href="/movie/sdb/rank/rpeople.nhn" title="영화인"><em>영화인</em></a></li>
    <!-- li><a href="/movie/sdb/rank/rfestival.nhn" title="영화제" class="db_tab03"><em>영화제</em></a></li -->
    <!-- li><a href="/movie/sdb/rank/rcompany.nhn" title="영화사" class="db_tab04"><em>영화사</em></a></li -->
    <!-- li><a href="/movie/sdb/rank/rnews.nhn" title="기자영화" class="db_tab05"><em>기자</em></a></li -->
    <!-- li><a href="/movie/sdb/rank/rreview.nhn" title="네티즌리뷰" class="db_tab06"><em>네티즌리뷰</em></a></li -->
    <li><a class="db_tab07" href="/movie/sdb/rank/rreserve.nhn" title="예매"><em>예매</em></a></li>
    <li><a class="db_tab08" href="/movie/sdb/rank/rboxoffice.nhn" title="박스오피스"><em>박스오피스</em></a></li>
    </ul>
    <!-- Content Body -->
    <div class="type_1" id="cbody">
    <div id="old_content">
    <h4 class="tlt"><img alt="영화랭킹" height="15" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/tlt_ranking_movie.gif" width="65"/>
    </h4>
    <!-- 탭메뉴 -->
    <div class="tab_type_6">
    <ul><!--활성화된 탭의 이미지는 _on.gif 입니다-->
    <li><a href="rmovie.nhn?sel=cnt&amp;date=20170804"><img alt="조회순" height="28" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/tab_movie_1_off.gif" width="112"/></a></li>
    <li><a href="rmovie.nhn?sel=cur&amp;date=20170804"><img alt="평점순(현재상영영화)" height="28" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/tab_movie_2_on.gif" width="126"/></a></li>
    <li><a href="rmovie.nhn?sel=pnt&amp;date=20170804"><img alt="평점순(모든영화)" height="28" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/tab_movie_3_off.gif" width="126"/></a></li>
    </ul>
    <p class="r_date">2017.08.04 <a href="rmovie.nhn?sel=cur&amp;tg=0&amp;date=20170803"><img alt="prev" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/btn_prev.gif" style="margin-right:1px;" width="13"/></a><a href="rmovie.nhn?sel=cur&amp;tg=0&amp;date=20170805"><img alt="next" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/btn_next.gif" width="13"/></a></p>
    </div>
    <!-- //탭메뉴 -->
    <!-- 랭킹 리스트 -->
    <table cellspacing="0" class="list_ranking">
    <caption class="blind">랭킹 테이블</caption>
    <col width="6%"/><col width="*"/><col width="15%"/><col width="3%"/><col width="12%"/><col width="2%"/><col width="5%"/>
    <thead>
    <tr>
    <th scope="col">순위</th>
    <th scope="col">영화명</th>
    <th colspan="3" scope="col">평점</th>
    <th colspan="2" scope="col">변동폭</th>
    </tr>
    </thead>
    <tbody>
    <tr><td class="blank01" colspan="8"></td></tr>
    <!-- 예제
    				<tr>
    					<td class="ac"><img src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g50.gif" alt="50" width="14" height="13"></td>
    					<td class="title"><a href="#">트랜스포머</a></td>
    					<td class="ac"><img src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" alt="down" width="7" height="10"></td>
    					<td class="range ac">7</td>
    				</tr>
    				-->
    <tr>
    <td class="ac"><img alt="01" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r01.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=62586" title="다크 나이트">다크 나이트</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:93.19999694824219%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.32</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=62586">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="02" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r02.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=164290" title="킹 오브 프리즘 프라이드 더 히어로">킹 오브 프리즘 프라이드 더 히어로</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:92.79999732971191%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.28</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=164290">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="03" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r03.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=152160" title="킹 오브 프리즘">킹 오브 프리즘</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:92.5%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.25</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=152160">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="04" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r04.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=10448" title="오즈의 마법사">오즈의 마법사</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:92.29999542236328%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.23</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=10448">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="05" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r05.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=154437" title="내 사랑">내 사랑</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:92.29999542236328%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.23</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=154437">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="up" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_up_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="06" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r06.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=160135" title="서서평, 천천히 평온하게">서서평, 천천히 평온하게</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:92.29999542236328%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.23</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=160135">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="07" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r07.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=10217" title="로보캅">로보캅</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:92.10000038146973%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.21</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=10217">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="up" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_up_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="08" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r08.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=76309" title="플립">플립</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:91.99999809265137%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.20</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=76309">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="up" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_up_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="09" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r09.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=159054" title="명탐정 코난:진홍의 연가">명탐정 코난:진홍의 연가</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:91.80000305175781%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.18</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=159054">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">2</td>
    </tr>
    <tr>
    <td class="ac"><img alt="010" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_r10.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=31827" title="헤드윅">헤드윅</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:91.80000305175781%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.18</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=31827">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr><td class="line01" colspan="8"></td></tr>
    <tr>
    <td class="ac"><img alt="11" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g11.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=153621" title="댄서">댄서</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:91.40000343322754%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.14</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=153621">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="12" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g12.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=38444" title="이터널 선샤인">이터널 선샤인</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:91.00000381469727%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.10</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=38444">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="13" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g13.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=17970" title="샤인">샤인</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:90.9000015258789%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.09</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=17970">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="14" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g14.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=36944" title="올드보이">올드보이</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:90.50000190734863%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.05</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=36944">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="15" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g15.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=95767" title="어네스트와 셀레스틴">어네스트와 셀레스틴</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:90.50000190734863%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.05</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=95767">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="16" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g16.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=27350" title="기쿠지로의 여름">기쿠지로의 여름</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:90.20000457763672%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.02</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=27350">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="17" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g17.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=125417" title="파도가 지나간 자리">파도가 지나간 자리</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:90.0%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">9.00</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=125417">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="18" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g18.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=146469" title="택시운전사">택시운전사</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:89.89999771118164%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.99</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=146469">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="up" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_up_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="19" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g19.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=134772" title="눈길">눈길</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:89.39999580383301%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.94</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=134772">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="20" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g20.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=162173" title="노무현입니다">노무현입니다</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:89.30000305175781%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.93</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=162173">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr><td class="line01" colspan="8"></td></tr>
    <tr>
    <td class="ac"><img alt="21" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g21.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=18682" title="스타쉽 트루퍼스">스타쉽 트루퍼스</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:89.0999984741211%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.91</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=18682">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="22" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g22.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=27260" title="파이트 클럽">파이트 클럽</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:89.0999984741211%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.91</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=27260">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="23" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g23.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=80774" title="청원">청원</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:88.69999885559082%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.87</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=80774">평점주기</a></td>
    <!----------------------------------------->
    <td class="new_icon" colspan="2"><img alt="new" height="5" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_new_1.gif" width="20"/></td>
    </tr>
    <tr>
    <td class="ac"><img alt="24" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g24.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=10800" title="토탈 리콜">토탈 리콜</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:88.59999656677246%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.86</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=10800">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="25" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g25.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=156477" title="극장판 짱구는 못말려 : 습격!! 외계인 덩덩이">극장판 짱구는 못말려 : 습격!! 외계인 덩덩이</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:88.4000015258789%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.84</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=156477">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="26" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g26.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=149481" title="연애담">연애담</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:87.60000228881836%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.76</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=149481">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="27" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g27.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=150198" title="너의 이름은.">너의 이름은.</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:87.60000228881836%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.76</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=150198">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="28" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g28.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=132626" title="슈퍼배드 3">슈퍼배드 3</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:87.39999771118164%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.74</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=132626">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="29" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g29.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=154980" title="꿈의 제인">꿈의 제인</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:87.10000038146973%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.71</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=154980">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="30" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g30.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=156091" title="심야식당2">심야식당2</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:86.19999885559082%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.62</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=156091">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr><td class="line01" colspan="8"></td></tr>
    <tr>
    <td class="ac"><img alt="31" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g31.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=134963" title="라라랜드">라라랜드</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:85.9000015258789%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.59</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=134963">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="32" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g32.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=152396" title="카3: 새로운 도전">카3: 새로운 도전</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:85.79999923706055%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.58</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=152396">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">2</td>
    </tr>
    <tr>
    <td class="ac"><img alt="33" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g33.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=125447" title="오두막">오두막</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:84.89999771118164%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.49</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=125447">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="34" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g34.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=135874" title="스파이더맨: 홈커밍">스파이더맨: 홈커밍</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:84.70000267028809%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.47</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=135874">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="35" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g35.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=143435" title="옥자">옥자</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:84.70000267028809%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.47</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=143435">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">2</td>
    </tr>
    <tr>
    <td class="ac"><img alt="36" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g36.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=53152" title="500일의 썸머">500일의 썸머</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:83.90000343322754%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.39</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=53152">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="37" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g37.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=32667" title="복수는 나의 것">복수는 나의 것</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:83.4000015258789%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.34</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=32667">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="38" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g38.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=146480" title="덩케르크">덩케르크</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:83.10000419616699%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.31</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=146480">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="39" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g39.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=158910" title="예수는 역사다">예수는 역사다</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:81.40000343322754%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">8.14</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=158910">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="40" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g40.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=40932" title="매치 포인트">매치 포인트</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:79.6999979019165%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">7.97</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=40932">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr><td class="line01" colspan="8"></td></tr>
    <tr>
    <td class="ac"><img alt="41" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g41.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=144988" title="7번째 내가 죽던 날">7번째 내가 죽던 날</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:78.4000015258789%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">7.84</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=144988">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="42" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g42.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=154262" title="위시 어폰">위시 어폰</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:77.10000038146973%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">7.71</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=154262">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="43" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g43.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=152616" title="47 미터">47 미터</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:74.00000095367432%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">7.40</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=152616">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="44" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g44.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=38766" title="친절한 금자씨">친절한 금자씨</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:72.60000228881836%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">7.26</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=38766">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="45" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g45.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=114268" title="송 투 송">송 투 송</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:70.3000020980835%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">7.03</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=114268">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="46" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g46.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=162956" title="그 후">그 후</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:65.99999904632568%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">6.60</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=162956">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="na" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/></td>
    <td class="range ac">0</td>
    </tr>
    <tr>
    <td class="ac"><img alt="47" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g47.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=59845" title="박쥐">박쥐</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:60.900001525878906%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">6.09</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=59845">평점주기</a></td>
    <!----------------------------------------->
    <td class="new_icon" colspan="2"><img alt="new" height="5" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_new_1.gif" width="20"/></td>
    </tr>
    <tr>
    <td class="ac"><img alt="48" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g48.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=57675" title="싸이보그지만 괜찮아">싸이보그지만 괜찮아</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:51.70000076293945%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">5.17</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=57675">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr>
    <td class="ac"><img alt="49" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/common/bullet_r_g49.gif" width="14"/></td>
    <td class="title">
    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=146506" title="군함도">군함도</a>
    </div>
    </td>
    <!-- 평점순일 때 평점 추가하기  -->
    <td><div class="point_type_2"><div class="mask" style="width:49.49999809265137%"><img alt="" height="14" src="https://ssl.pstatic.net/imgmovie/2007/img/common/point_type_2_bg_on.gif" width="79"/></div></div></td>
    <td class="point">4.95</td>
    <td class="ac"><a class="txt_link" href="/movie/point/af/list.nhn?st=mcode&amp;sword=146506">평점주기</a></td>
    <!----------------------------------------->
    <td class="ac"><img alt="down" class="arrow" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/></td>
    <td class="range ac">1</td>
    </tr>
    <tr><td class="blank01" colspan="8"></td></tr>
    </tbody>
    </table>
    <!-- 페이지 네비게이션 시작 -->
    <!-- 페이지 네비게이션 끝 -->
    <!-- //랭킹 리스트 -->
    <span class="txt_mark">※</span> <span class="txt_term">집계기준 : <strong>2017.08.04</strong>일 까지 네이버영화에 수록 된 영화의 관람 후 평점</span>
    <!-- 네이버 영화평점랭킹 선정방법 -->
    <div class="box_choice_way">
    <img alt="네이버 영화평점랭킹 선정방법" height="13" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_01.gif" width="154"/>
    <dl class="choice_way">
    <dt><img alt="집계기준" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_01_1.gif" width="39"/></dt><dd>전국기준 현재 상영되고 있는 영화 중 <em>평점 응답자가 <strong>300명</strong> 이상</em>인 경우</dd>
    <dt><img alt="집계기간" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_01_2.gif" width="40"/></dt><dd>전일까지의 누적 평점</dd>
    <dt><img alt="표본오차" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_01_3.gif" width="40"/></dt><dd><em>95% 신뢰수준에서 ±5.65</em></dd>
    </dl>
    <table cellpadding="0" cellspacing="0" class="choice_way_data">
    <col width="48"/><col width="73"/><col width="73"/><col width="73"/><col width="73"/><col width="73"/><col width="110"/>
    <tr>
    <th class="bgwhite" scope="row">구분</th>
    <td>N</td>
    <td>Range</td>
    <td>Minimum</td>
    <td>Maximum</td>
    <td>Mean</td>
    <td>Std.Deviation</td>
    </tr>
    <tr>
    <th class="bgwhite" scope="row">평점</th>
    <td class="range ac">26</td>
    <td class="range ac">4.39</td>
    <td class="range ac">4.75</td>
    <td class="range ac">9.14</td>
    <td class="range ac">7.59</td>
    <td class="range ac">7.59</td>
    </tr>
    </table>
    <dl class="choice_way_qna">
    <dt><img alt="왜 평점응답자를 300명 이상으로 정하나요?" height="12" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_02.gif" width="221"/></dt>
    <dd>일반적인 여론조사에서의 최소 응답자수가 300명이기 때문입니다.</dd>
    <dt><img alt="표본오차 95% 신뢰수준에서 ±5.65가 무슨 뜻인가요?" height="12" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_03.gif" width="271"/></dt>
    <dd>동일한 실험을 100번 했을 경우 95번은 ±5.65% 범위 내에서 동일한 결과가 나온다는 말입니다.</dd>
    <dt><img alt="Descriptive Statistics는 어떻게 보는건가요?" height="12" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/txt_movie_ranking_04.gif" width="234"/></dt>
    <dd>
    <ul>
    <li>N=Case의 숫자</li>
    <li>Range=응답자의 범위</li>
    <li>Minimum=최소 응답값</li>
    <li>Maximum=최대응답값</li>
    <li>Mean=평균</li>
    <li>Std.Deviation=표준편자</li>
    </ul>
    </dd>
    </dl>
    </div>
    <!-- //네이버 영화평점랭킹 선정방법 -->
    <!-- 탑버튼 -->
    <div class="go_top">
    <a href="#gnb_top"><img alt="TOP" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/common/btn_top.gif" width="30"/></a>
    </div>
    <!-- //탑버튼 -->
    <img alt="" class="clear" src="https://ssl.pstatic.net/imgmovie/2007/img/common/blank.gif"/>
    <!-- //Content Body -->
    <script src="/common/js/jindo2.js" type="text/javascript"></script>
    </div>
    <div id="assistant">
    <!-- 우측 메뉴 -->
    <!-- 영화 인기검색어 -->
    <div class="box_type_1 mb_8">
    <h3><img alt="영화 인기검색어" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/tlt_r_best_movie.gif" width="75"/></h3>
    <ul class="r_ranking">
    <li class="ranking01">
    <a class="b" href="/movie/bi/mi/basic.nhn?code=151153" onclick="clickcr(this,'pop.list','151153','1',event);" title="아쿠아맨"><span class="blind">1위</span>아쿠아맨</a>
    <span class="rank">
    <img alt="순위 변동 없음" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking02">
    <a href="/movie/bi/mi/basic.nhn?code=157297" onclick="clickcr(this,'pop.list','157297','2',event);" title="마약왕"><span class="blind">2위</span>마약왕</a>
    <span class="rank">
    <img alt="순위 변동 없음" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking03">
    <a href="/movie/bi/mi/basic.nhn?code=166092" onclick="clickcr(this,'pop.list','166092','3',event);" title="PMC: 더 벙커"><span class="blind">3위</span>PMC: 더 벙커</a>
    <span class="rank">
    <img alt="순위 변동 없음" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking04">
    <a href="/movie/bi/mi/basic.nhn?code=164139" onclick="clickcr(this,'pop.list','164139','4',event);" title="범블비"><span class="blind">4위</span>범블비</a>
    <span class="rank">
    <img alt="순위 상승" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_up_1.gif" width="7"/>2</span>
    <li class="ranking05">
    <a href="/movie/bi/mi/basic.nhn?code=164101" onclick="clickcr(this,'pop.list','164101','5',event);" title="스윙키즈"><span class="blind">5위</span>스윙키즈</a>
    <span class="rank">
    <img alt="순위 하락" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_down_1.gif" width="7"/>1</span>
    </li></li></li></li></li></ul>
    <!--[D] 더보기 위치 이동 -->
    <a class="more" href="/movie/sdb/rank/rmovie.nhn" onclick="clickcr(this,'pop.more','','',event);">더보기</a>
    <p class="term">2018.12.28</p>
    </div>
    <!-- 영화인 인기검색어 -->
    <div class="box_type_1 mb_8">
    <h3><img alt="영화인 인기검색어" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/super_db/tlt_r_best_star.gif" width="85"/></h3>
    <ul class="r_ranking">
    <li class="ranking01">
    <a class="b" href="/movie/bi/pi/basic.nhn?st=1&amp;code=80780" onclick="clickcr(this,'peo.list','80780','1',event);" title="앰버 허드"><span class="blind">1위</span>앰버 허드</a>
    <span class="rank">
    <img alt="" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking02">
    <a href="/movie/bi/pi/basic.nhn?st=1&amp;code=51993" onclick="clickcr(this,'peo.list','51993','2',event);" title="제임스 완"><span class="blind">2위</span>제임스 완</a>
    <span class="rank">
    <img alt="" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking03">
    <a href="/movie/bi/pi/basic.nhn?st=1&amp;code=81371" onclick="clickcr(this,'peo.list','81371','3',event);" title="제이슨 모모아"><span class="blind">3위</span>제이슨 모모아</a>
    <span class="rank">
    <img alt="" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking04">
    <a href="/movie/bi/pi/basic.nhn?st=1&amp;code=113530" onclick="clickcr(this,'peo.list','113530','4',event);" title="라미 말렉"><span class="blind">4위</span>라미 말렉</a>
    <span class="rank">
    <img alt="" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    <li class="ranking05">
    <a href="/movie/bi/pi/basic.nhn?st=1&amp;code=43284" onclick="clickcr(this,'peo.list','43284','5',event);" title="마동석"><span class="blind">5위</span>마동석</a>
    <span class="rank">
    <img alt="" height="10" src="https://ssl.pstatic.net/imgmovie/2007/img/common/icon_na_1.gif" width="7"/>0</span>
    </li></li></li></li></li></ul>
    <a class="more" href="/movie/sdb/rank/rpeople.nhn" onclick="clickcr(this,'peo.more','','',event);">더보기</a>
    <p class="term">2018.12.28</p>
    </div>
    <!--티켓예매순-->
    <div class="box_type_1 mb_8">
    <h3><img alt="티켓예매순" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/running/tlt_r_reservation.gif" width="51"/></h3>
    <div id="reserveRanking0" style="display:block">
    <ul class="r_ranking">
    <li class="ranking01"><a class="b" href="/movie/bi/mi/basic.nhn?code=151153" onclick="clickcr(this,'tck.list','151153','1',event);" title="아쿠아맨"><span class="blind">1위</span>아쿠아맨</a><span class="ratio check">24.66%</span></li>
    <li class="ranking02"><a href="/movie/bi/mi/basic.nhn?code=166092" onclick="clickcr(this,'tck.list','166092','2',event);" title="PMC: 더 벙커"><span class="blind">2위</span>PMC: 더 벙커</a> <span class="ratio">21.97%</span></li>
    <li class="ranking03"><a href="/movie/bi/mi/basic.nhn?code=156464" onclick="clickcr(this,'tck.list','156464','3',event);" title="보헤미안 랩소디"><span class="blind">3위</span>보헤미안 랩소디</a> <span class="ratio">10.45%</span></li>
    <li class="ranking04"><a href="/movie/bi/mi/basic.nhn?code=164139" onclick="clickcr(this,'tck.list','164139','4',event);" title="범블비"><span class="blind">4위</span>범블비</a> <span class="ratio">10.42%</span></li>
    <li class="ranking05"><a href="/movie/bi/mi/basic.nhn?code=180379" onclick="clickcr(this,'tck.list','180379','5',event);" title="점박이 한반도의 공룡2 : 새로운 낙원"><span class="blind">5위</span>점박이 한반도의 공..</a> <span class="ratio">7.56%</span></li>
    </ul>
    <a class="more" href="/movie/sdb/rank/rreserve.nhn" id="ticketRankLink" onclick="clickcr(this,'tck.more','','',event);">더보기</a>
    <div class="term_1"><img alt="출처:YES24" height="12" src="https://ssl.pstatic.net/imgmovie/2007/img/common/txt_source_yes24_02.gif" width="54"/><div class="date">2018.12.29</div></div>
    </div>
    </div>
    <!--//티켓예매순-->
    <!--박스오피스-->
    <div class="box_type_1 mb_8">
    <h3><img alt="박스오피스" height="11" src="https://ssl.pstatic.net/imgmovie/2007/img/running/tlt_r_boxoffice.gif" width="51"/></h3>
    <ul class="r_ranking box">
    <li class="ranking01"><a class="b" href="/movie/bi/mi/basic.nhn?code=151153" onclick="clickcr(this,'box.list','151153','1',event);" title="아쿠아맨"><span class="blind">1위</span>아쿠아맨</a> <span "="" class="ratio check"><em>966124</em> 명</span></li>
    <li class="ranking02"><a href="/movie/bi/mi/basic.nhn?code=157297" onclick="clickcr(this,'box.list','157297','2',event);" title="마약왕"><span class="blind">2위</span>마약왕</a> <span class="ratio "><em>755511</em> 명</span></li>
    <li class="ranking03"><a href="/movie/bi/mi/basic.nhn?code=164101" onclick="clickcr(this,'box.list','164101','3',event);" title="스윙키즈"><span class="blind">3위</span>스윙키즈</a> <span class="ratio "><em>371406</em> 명</span></li>
    <li class="ranking04"><a href="/movie/bi/mi/basic.nhn?code=156464" onclick="clickcr(this,'box.list','156464','4',event);" title="보헤미안 랩소디"><span class="blind">4위</span>보헤미안 랩소디</a> <span class="ratio "><em>305539</em> 명</span></li>
    <li class="ranking05"><a href="/movie/bi/mi/basic.nhn?code=150688" onclick="clickcr(this,'box.list','150688','5',event);" title="그린치"><span class="blind">5위</span>그린치</a> <span class="ratio "><em>162905</em> 명</span></li>
    </ul>
    <a class="more" href="/movie/sdb/rank/rboxoffice.nhn" onclick="clickcr(this,'box.more','','',event);">더보기</a>
    <div class="term_1"><span class="cnt">주말관객 기준</span><div class="date">2018.12.21-2018.12.23</div></div>
    </div>
    <!--//박스오피스-->
    </div>
    <img alt="" class="clear" src="https://ssl.pstatic.net/imgmovie/2007/img/common/blank.gif"/>
    </div>
    <!-- //Content Body -->
    </div>
    </div>
    </div>
    <!-- //content -->
    </div>
    <!-- //container -->
    <!-- Footer -->
    <script src="/common/js/jindo/component/1.0.2/jindo.Component.js" type="text/javascript"></script>
    <script src="/common/js/jindo/component/1.0.2/jindo.UIComponent.js" type="text/javascript"></script>
    <!-- footer -->
    <div id="footer">
    <div class="in_footer">
    <div class="foot_con">
    <ul>
    <li class="first"><a href="http://www.naver.com/rules/service.html" onclick="clickcr(this, 'fot.agreement', '', '', event);" target="_blank">이용약관</a></li>
    <li><a href="http://www.naver.com/rules/privacy.html" onclick="clickcr(this, 'fot.privacy', '', '', event);" target="_blank"><strong>개인정보처리방침</strong></a></li>
    <li><a href="http://www.naver.com/rules/disclaimer.html" onclick="clickcr(this, 'fot.disclaimer', '', '', event);" target="_blank">책임의 한계와 법적고지</a></li>
    <li><a href="https://help.naver.com/support/service/main.nhn?serviceNo=800" onclick="clickcr(this, 'fot.help', '', '', event);" target="_blank">영화 고객센터</a></li>
    </ul>
    <p class="info">본 콘텐츠의 저작권은 저작권자 또는 제공처에 있으며, 이를 무단 이용하는 경우 저작권법 등에 따라 법적 책임을 질 수 있습니다.</p>
    <p class="info">
    					사업자등록번호 : 220-81-62517<span>통신판매업 신고번호</span> : 경기성남 제 2006 - 692호<span>대표이사 : 한성숙</span><span><a href="http://www.ftc.go.kr/info/bizinfo/communicationList.jsp" onclick="clickcr(this, 'fot.bizinfo', '', '', event);">사업자등록정보 확인</a></span><br/>
    					주소 : 경기도 성남시 분당구 불정로 6 네이버 그린팩토리 <span>대표전화 : 1588-3820</span>
    </p>
    <address>
    <a class="logo" href="http://www.navercorp.com" onclick="clickcr(this, 'fot.nhn', '', '', event);" target="_blank"><img alt="NAVER" height="11" src="https://ssl.pstatic.net/static/movie/2013/07/logo_naver.png" width="63"/></a>
    <em>Copyright ©</em>
    <a href="http://www.navercorp.com" onclick="clickcr(this, 'fot.corp', '', '', event);" target="_blank">NAVER Corp.</a>
    <span>All Rights Reserved.</span>
    </address>
    </div>
    </div>
    </div>
    <!-- //footer -->
    <script type="text/javascript">
    
    if (false) {
    	var alertType = "NONE";
    	var koreanTitle = "";
    	var movieCode = "0";
    	var userReserveCount = "0";
    	var todayDatetime = "20181229155844";
    	var endDatetimeAfterTwoDays = "00000000000000";
    	
    	
    	if (movieCode > 0) {
    		openWriteActualPointAlert (alertType, koreanTitle, movieCode, userReserveCount, todayDatetime, endDatetimeAfterTwoDays);
    	}
    }
    
    function openWriteActualPointAlert (alertType, koreanTitle, movieCode, count, today, endDate) {
    	if (alertType == "ONE") {
    		setCookieLastUserReserveDate(today, endDate);
    		if (confirm("관람하신 " + koreanTitle + "에\n평점 등록 시 네이버페이 마일리지 500원 적립!\n지금 평점쓰기 메뉴로 이동하시겠습니까?")) {
    			top.location.href = "http://movie.naver.com/movie/bi/mi/point.nhn?code=" + movieCode;
    		}
    	} else if (alertType == "MORE") {
    		setCookieLastUserReserveDate(today, endDate);
    		if (confirm("관람하신 작품에 평점을 등록해주세요\n작품당 네이버페이 마일리지 500원씩 적립!\n평점 미등록작 리스트를 확인하시겠습니까?")) {
    			top.location.href = "http://ticket.movie.naver.com/Order/OverdueList.aspx";
    		}
    	}
    }
    
    function setCookieLastUserReserveDate(today, endDate) {
    	var cookieForNotOpenActualPointPopup = jindo.$Cookie();
    	
    	
    	cookieForNotOpenActualPointPopup.remove("lastUserReserveDatetime");
    	cookieForNotOpenActualPointPopup.remove("lastUserReserveCheckDatetime");
    	
    	cookieForNotOpenActualPointPopup.set("lastUserReserveDatetime", endDate, 9999, "movie.naver.com");
    	cookieForNotOpenActualPointPopup.set("lastUserReserveCheckDatetime", today, 9999, "movie.naver.com");
    }
    
    </script>
    <script type="text/javascript">
    	
    		
    		
    		
    		
    			var alertMessage = "지원되지 않는 브라우저로 서비스 이용에 제한이 있습니다.";
    		
    	
    
    	function getBrowser() {
    		var ua = navigator.userAgent;
    		if (/NAVER/.test(ua)) {
    			return "NAVER_APP";
    		} else if (/IEMobile/.test(ua)) {
    			return "INTERNET_EXPLORER_MOBILE";
    		} else if (/MSIE/.test(ua) || /Trident/.test(ua)) {
    			return "INTERNET_EXPLORER";
    		} else if (/Firefox/.test(ua)) {
    			return "FIREFOX";
    		} else if (/Opera\//.test(ua) || /OPR\//.test(ua)) {
    			return "OPERA";
    		}  else if (/Swing\//.test(ua)) {
    			return "SWING";
    		} else if (/Chrome\//.test(ua) || /CriOS\//.test(ua)) {
    			return "CHROME";
    		} else if (/BAND\//.test(ua)) {
    			return "BAND_APP";
    		} else if (/FBAN\/FBIOS/.test(ua)) {
    			return "FACEBOOK_APP";
    		} else if (/Twitter/.test(ua)) {
    			return "TWITTER_APP";
    		} else if (/KAKAOTALK/.test(ua)) {
    			return "KAKAOTALK_APP";
    		} else if (/Android/.test(ua) && /Safari/.test(ua)) {
    			return "ANDROID_INTERNET_APP";
    		} else if (/Safari/.test(ua)) {
    			return "SAFARI";
    		}
    
    		return "";
    	}
    	
    	if (getBrowser() === "UNKNOWN" && jindo.$Cookie().get("notSupportBrowserAlert") != 'true') {
    		alert(alertMessage);
    		jindo.$Cookie().set("notSupportBrowserAlert", "true", "9999", "movie.naver.com");
    	}
    </script>
    <script src="/common/js/lcslog.js" type="text/javascript"></script>
    <script src="/common/js/jindo/component/1.0.2/jindo.Component.min.js" type="text/javascript"></script>
    <script charset="UTF-8" src="/common/js/vendor/jindo.WatchInput.js" type="text/javascript"></script>
    <script charset="UTF-8" src="/common/js/lib/Core.js?20181227143456" type="text/javascript"></script>
    <script charset="UTF-8" src="/common/js/lib/LNB.js?20181227143456" type="text/javascript"></script>
    <script charset="UTF-8" src="/common/js/lib/Search.js?20181227143456" type="text/javascript"></script>
    <script type="text/javascript">
    
    // nhn.movie.Search가 jindo 기반이어서 javascript로 전환함
    if (document.addEventListener) {
    	document.addEventListener("DOMContentLoaded", function () {
    		document.removeEventListener("DOMContentLoaded", arguments.callee, false);
    		loadFooter();
    	}, false);
    }
    // Internet Explorer
    else if (document.attachEvent) {
    	// onreadystatechange 는 모든 브라우저가 반환
    	document.attachEvent("onreadystatechange", function () {
    		if (document.readyState == "complete" || document.readyState == 'loaded') {
    			document.detachEvent("onreadystatechange", arguments.callee);
    			loadFooter();
    		}
    	});
    }
    
    function loadFooter() {
    	var goNaver = document.getElementById("lnb_gonaver");
    	goNaver.addEventListener("focus", focusonNaverIcon, false);
    
    	// LNB - 사용처를 못 찾음
    //   	var oLNB = new nhn.movie.LNB();
    	
    	// 상단 검색영역
    	var oSearch = new nhn.movie.Search({
    		area : "jSearchArea",
    		autosearch : "https://auto-movie.naver.com/ac?q_enc=UTF-8&st=1&r_lt=1&n_ext=1&t_koreng=1&r_format=json&r_enc=UTF-8&r_unicode=0&r_escape=1&q=",
    		movelink : "/movie/bi/mi/basic.nhn?code=",
    		peoplelink : "/movie/bi/pi/basic.nhn?code="
    	});
    	
    	getGNB();	
    }
    
    function focusonNaverIcon(event) {
    	event.preventDefault();	// jindo.$Event.CANCEL_DEFAULT 와 동일한 기능으로 추측됨
    	document.getElementById('ipt_tx_srch').value= "";
    	document.getElementById('search_placeholder').style = "display:inline;";
    	if (document.getElementById('jAutoComplate') != undefined && document.getElementById('jAutoComplate') !== null) {
    		document.getElementById('jAutoComplate').style = "display:none;"
    	}
    }
    
    
    window.addEventListener('pageshow', function(event) { lcs_do(); });
    
    document.addEventListener('click', function (event) {
    	var welSource = event.srcElement;	// jindo.$Element(oEvent.element);
    	if (!document.getElementById("gnb").contains(welSource)) {
    		gnbAllLayerClose();
    	}
    });
    </script>
    <!-- //Footer -->
    </div>
    </body>
    </html> 




```python
soup.find_all('div', 'tit5')
```




    [<div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=62586" title="다크 나이트">다크 나이트</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=164290" title="킹 오브 프리즘 프라이드 더 히어로">킹 오브 프리즘 프라이드 더 히어로</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=152160" title="킹 오브 프리즘">킹 오브 프리즘</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=10448" title="오즈의 마법사">오즈의 마법사</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=154437" title="내 사랑">내 사랑</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=160135" title="서서평, 천천히 평온하게">서서평, 천천히 평온하게</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=10217" title="로보캅">로보캅</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=76309" title="플립">플립</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=159054" title="명탐정 코난:진홍의 연가">명탐정 코난:진홍의 연가</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=31827" title="헤드윅">헤드윅</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=153621" title="댄서">댄서</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=38444" title="이터널 선샤인">이터널 선샤인</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=17970" title="샤인">샤인</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=36944" title="올드보이">올드보이</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=95767" title="어네스트와 셀레스틴">어네스트와 셀레스틴</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=27350" title="기쿠지로의 여름">기쿠지로의 여름</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=125417" title="파도가 지나간 자리">파도가 지나간 자리</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=146469" title="택시운전사">택시운전사</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=134772" title="눈길">눈길</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=162173" title="노무현입니다">노무현입니다</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=18682" title="스타쉽 트루퍼스">스타쉽 트루퍼스</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=27260" title="파이트 클럽">파이트 클럽</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=80774" title="청원">청원</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=10800" title="토탈 리콜">토탈 리콜</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=156477" title="극장판 짱구는 못말려 : 습격!! 외계인 덩덩이">극장판 짱구는 못말려 : 습격!! 외계인 덩덩이</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=149481" title="연애담">연애담</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=150198" title="너의 이름은.">너의 이름은.</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=132626" title="슈퍼배드 3">슈퍼배드 3</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=154980" title="꿈의 제인">꿈의 제인</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=156091" title="심야식당2">심야식당2</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=134963" title="라라랜드">라라랜드</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=152396" title="카3: 새로운 도전">카3: 새로운 도전</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=125447" title="오두막">오두막</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=135874" title="스파이더맨: 홈커밍">스파이더맨: 홈커밍</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=143435" title="옥자">옥자</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=53152" title="500일의 썸머">500일의 썸머</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=32667" title="복수는 나의 것">복수는 나의 것</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=146480" title="덩케르크">덩케르크</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=158910" title="예수는 역사다">예수는 역사다</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=40932" title="매치 포인트">매치 포인트</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=144988" title="7번째 내가 죽던 날">7번째 내가 죽던 날</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=154262" title="위시 어폰">위시 어폰</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=152616" title="47 미터">47 미터</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=38766" title="친절한 금자씨">친절한 금자씨</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=114268" title="송 투 송">송 투 송</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=162956" title="그 후">그 후</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=59845" title="박쥐">박쥐</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=57675" title="싸이보그지만 괜찮아">싸이보그지만 괜찮아</a>
     </div>, <div class="tit5">
     <a href="/movie/bi/mi/basic.nhn?code=146506" title="군함도">군함도</a>
     </div>]




```python
soup.find_all('div', 'tit5')[0]
```




    <div class="tit5">
    <a href="/movie/bi/mi/basic.nhn?code=62586" title="다크 나이트">다크 나이트</a>
    </div>




```python
soup.find_all('div', 'tit5')[0].a
```




    <a href="/movie/bi/mi/basic.nhn?code=62586" title="다크 나이트">다크 나이트</a>




```python
soup.find_all('div', 'tit5')[0].a.string
```




    '다크 나이트'




```python
soup.find_all('td', 'point')
```




    [<td class="point">9.32</td>,
     <td class="point">9.28</td>,
     <td class="point">9.25</td>,
     <td class="point">9.23</td>,
     <td class="point">9.23</td>,
     <td class="point">9.23</td>,
     <td class="point">9.21</td>,
     <td class="point">9.20</td>,
     <td class="point">9.18</td>,
     <td class="point">9.18</td>,
     <td class="point">9.14</td>,
     <td class="point">9.10</td>,
     <td class="point">9.09</td>,
     <td class="point">9.05</td>,
     <td class="point">9.05</td>,
     <td class="point">9.02</td>,
     <td class="point">9.00</td>,
     <td class="point">8.99</td>,
     <td class="point">8.94</td>,
     <td class="point">8.93</td>,
     <td class="point">8.91</td>,
     <td class="point">8.91</td>,
     <td class="point">8.87</td>,
     <td class="point">8.86</td>,
     <td class="point">8.84</td>,
     <td class="point">8.76</td>,
     <td class="point">8.76</td>,
     <td class="point">8.74</td>,
     <td class="point">8.71</td>,
     <td class="point">8.62</td>,
     <td class="point">8.59</td>,
     <td class="point">8.58</td>,
     <td class="point">8.49</td>,
     <td class="point">8.47</td>,
     <td class="point">8.47</td>,
     <td class="point">8.39</td>,
     <td class="point">8.34</td>,
     <td class="point">8.31</td>,
     <td class="point">8.14</td>,
     <td class="point">7.97</td>,
     <td class="point">7.84</td>,
     <td class="point">7.71</td>,
     <td class="point">7.40</td>,
     <td class="point">7.26</td>,
     <td class="point">7.03</td>,
     <td class="point">6.60</td>,
     <td class="point">6.09</td>,
     <td class="point">5.17</td>,
     <td class="point">4.95</td>]




```python
len(soup.find_all('td', 'point'))
```




    49




```python
soup.find_all('td', 'point')[0].string
```




    '9.32'




```python
movie_name = [soup.find_all('div', 'tit5')[n].a.string for n in range(0, 49)]
movie_name
```




    ['다크 나이트',
     '킹 오브 프리즘 프라이드 더 히어로',
     '킹 오브 프리즘',
     '오즈의 마법사',
     '내 사랑',
     '서서평, 천천히 평온하게',
     '로보캅',
     '플립',
     '명탐정 코난:진홍의 연가',
     '헤드윅',
     '댄서',
     '이터널 선샤인',
     '샤인',
     '올드보이',
     '어네스트와 셀레스틴',
     '기쿠지로의 여름',
     '파도가 지나간 자리',
     '택시운전사',
     '눈길',
     '노무현입니다',
     '스타쉽 트루퍼스',
     '파이트 클럽',
     '청원',
     '토탈 리콜',
     '극장판 짱구는 못말려 : 습격!! 외계인 덩덩이',
     '연애담',
     '너의 이름은.',
     '슈퍼배드 3',
     '꿈의 제인',
     '심야식당2',
     '라라랜드',
     '카3: 새로운 도전',
     '오두막',
     '스파이더맨: 홈커밍',
     '옥자',
     '500일의 썸머',
     '복수는 나의 것',
     '덩케르크',
     '예수는 역사다',
     '매치 포인트',
     '7번째 내가 죽던 날',
     '위시 어폰',
     '47 미터',
     '친절한 금자씨',
     '송 투 송',
     '그 후',
     '박쥐',
     '싸이보그지만 괜찮아',
     '군함도']




```python
movie_point = [soup.find_all('td', 'point')[n].string for n in range(0, 49)]
movie_point
```




    ['9.32',
     '9.28',
     '9.25',
     '9.23',
     '9.23',
     '9.23',
     '9.21',
     '9.20',
     '9.18',
     '9.18',
     '9.14',
     '9.10',
     '9.09',
     '9.05',
     '9.05',
     '9.02',
     '9.00',
     '8.99',
     '8.94',
     '8.93',
     '8.91',
     '8.91',
     '8.87',
     '8.86',
     '8.84',
     '8.76',
     '8.76',
     '8.74',
     '8.71',
     '8.62',
     '8.59',
     '8.58',
     '8.49',
     '8.47',
     '8.47',
     '8.39',
     '8.34',
     '8.31',
     '8.14',
     '7.97',
     '7.84',
     '7.71',
     '7.40',
     '7.26',
     '7.03',
     '6.60',
     '6.09',
     '5.17',
     '4.95']




```python
date = pd.date_range('2017-5-1', periods=100, freq='D')
date
```




    DatetimeIndex(['2017-05-01', '2017-05-02', '2017-05-03', '2017-05-04',
                   '2017-05-05', '2017-05-06', '2017-05-07', '2017-05-08',
                   '2017-05-09', '2017-05-10', '2017-05-11', '2017-05-12',
                   '2017-05-13', '2017-05-14', '2017-05-15', '2017-05-16',
                   '2017-05-17', '2017-05-18', '2017-05-19', '2017-05-20',
                   '2017-05-21', '2017-05-22', '2017-05-23', '2017-05-24',
                   '2017-05-25', '2017-05-26', '2017-05-27', '2017-05-28',
                   '2017-05-29', '2017-05-30', '2017-05-31', '2017-06-01',
                   '2017-06-02', '2017-06-03', '2017-06-04', '2017-06-05',
                   '2017-06-06', '2017-06-07', '2017-06-08', '2017-06-09',
                   '2017-06-10', '2017-06-11', '2017-06-12', '2017-06-13',
                   '2017-06-14', '2017-06-15', '2017-06-16', '2017-06-17',
                   '2017-06-18', '2017-06-19', '2017-06-20', '2017-06-21',
                   '2017-06-22', '2017-06-23', '2017-06-24', '2017-06-25',
                   '2017-06-26', '2017-06-27', '2017-06-28', '2017-06-29',
                   '2017-06-30', '2017-07-01', '2017-07-02', '2017-07-03',
                   '2017-07-04', '2017-07-05', '2017-07-06', '2017-07-07',
                   '2017-07-08', '2017-07-09', '2017-07-10', '2017-07-11',
                   '2017-07-12', '2017-07-13', '2017-07-14', '2017-07-15',
                   '2017-07-16', '2017-07-17', '2017-07-18', '2017-07-19',
                   '2017-07-20', '2017-07-21', '2017-07-22', '2017-07-23',
                   '2017-07-24', '2017-07-25', '2017-07-26', '2017-07-27',
                   '2017-07-28', '2017-07-29', '2017-07-30', '2017-07-31',
                   '2017-08-01', '2017-08-02', '2017-08-03', '2017-08-04',
                   '2017-08-05', '2017-08-06', '2017-08-07', '2017-08-08'],
                  dtype='datetime64[ns]', freq='D')




```python
import urllib
from tqdm import tqdm_notebook

movie_date = []
movie_name = []
movie_point = []

for today in tqdm_notebook(date):
    html = "http://movie.naver.com/" + \
                                    "movie/sdb/rank/rmovie.nhn?sel=cur&date={date}"
    response = urlopen(html.format(date=
                                   urllib.parse.quote(today.strftime('%Y%m%d'))))
    soup = BeautifulSoup(response, "html.parser")
    
    end = len(soup.find_all('td', 'point'))
    
    movie_date.extend([today for n in range(0, end)])
    movie_name.extend([soup.find_all('div', 'tit5')[n].a.string for n in range(0, end)])
    movie_point.extend([soup.find_all('td', 'point')[n].string for n in range(0, end)])
```


    HBox(children=(IntProgress(value=0), HTML(value='')))


    
    


```python
len(movie_date), len(movie_name), len(movie_point)
```




    (4723, 4723, 4723)




```python
movie = pd.DataFrame({'date':movie_date, 'name':movie_name, 
                                      'point':movie_point})
movie.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>name</th>
      <th>point</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2017-05-01</td>
      <td>히든 피겨스</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2017-05-01</td>
      <td>사운드 오브 뮤직</td>
      <td>9.36</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2017-05-01</td>
      <td>시네마 천국</td>
      <td>9.29</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2017-05-01</td>
      <td>미스 슬로운</td>
      <td>9.26</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2017-05-01</td>
      <td>잉여들의 히치하이킹</td>
      <td>9.25</td>
    </tr>
  </tbody>
</table>
</div>




```python
movie.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4723 entries, 0 to 4722
    Data columns (total 3 columns):
    date     4723 non-null datetime64[ns]
    name     4723 non-null object
    point    4723 non-null object
    dtypes: datetime64[ns](1), object(2)
    memory usage: 110.8+ KB
    


```python
movie['point'] = movie['point'].astype(float)
movie.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4723 entries, 0 to 4722
    Data columns (total 3 columns):
    date     4723 non-null datetime64[ns]
    name     4723 non-null object
    point    4723 non-null float64
    dtypes: datetime64[ns](1), float64(1), object(1)
    memory usage: 110.8+ KB
    


```python
import numpy as np

movie_unique = pd.pivot_table(movie, index=['name'], aggfunc=np.sum)
movie_best = movie_unique.sort_values(by='point', ascending=False)
movie_best.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>point</th>
    </tr>
    <tr>
      <th>name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>댄서</th>
      <td>914.60</td>
    </tr>
    <tr>
      <th>서서평, 천천히 평온하게</th>
      <td>889.64</td>
    </tr>
    <tr>
      <th>오두막</th>
      <td>861.65</td>
    </tr>
    <tr>
      <th>라라랜드</th>
      <td>858.89</td>
    </tr>
    <tr>
      <th>너의 이름은.</th>
      <td>738.42</td>
    </tr>
  </tbody>
</table>
</div>




```python
tmp = movie.query('name == ["노무현입니다"]')
tmp
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>name</th>
      <th>point</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1162</th>
      <td>2017-05-25</td>
      <td>노무현입니다</td>
      <td>9.20</td>
    </tr>
    <tr>
      <th>1215</th>
      <td>2017-05-26</td>
      <td>노무현입니다</td>
      <td>8.97</td>
    </tr>
    <tr>
      <th>1255</th>
      <td>2017-05-27</td>
      <td>노무현입니다</td>
      <td>9.04</td>
    </tr>
    <tr>
      <th>1298</th>
      <td>2017-05-28</td>
      <td>노무현입니다</td>
      <td>9.04</td>
    </tr>
    <tr>
      <th>1340</th>
      <td>2017-05-29</td>
      <td>노무현입니다</td>
      <td>9.05</td>
    </tr>
    <tr>
      <th>1381</th>
      <td>2017-05-30</td>
      <td>노무현입니다</td>
      <td>9.05</td>
    </tr>
    <tr>
      <th>1424</th>
      <td>2017-05-31</td>
      <td>노무현입니다</td>
      <td>9.03</td>
    </tr>
    <tr>
      <th>1467</th>
      <td>2017-06-01</td>
      <td>노무현입니다</td>
      <td>9.04</td>
    </tr>
    <tr>
      <th>1515</th>
      <td>2017-06-02</td>
      <td>노무현입니다</td>
      <td>9.04</td>
    </tr>
    <tr>
      <th>1565</th>
      <td>2017-06-03</td>
      <td>노무현입니다</td>
      <td>9.02</td>
    </tr>
    <tr>
      <th>1609</th>
      <td>2017-06-04</td>
      <td>노무현입니다</td>
      <td>9.02</td>
    </tr>
    <tr>
      <th>1652</th>
      <td>2017-06-05</td>
      <td>노무현입니다</td>
      <td>9.02</td>
    </tr>
    <tr>
      <th>1697</th>
      <td>2017-06-06</td>
      <td>노무현입니다</td>
      <td>9.02</td>
    </tr>
    <tr>
      <th>1745</th>
      <td>2017-06-07</td>
      <td>노무현입니다</td>
      <td>9.02</td>
    </tr>
    <tr>
      <th>1794</th>
      <td>2017-06-08</td>
      <td>노무현입니다</td>
      <td>9.02</td>
    </tr>
    <tr>
      <th>1844</th>
      <td>2017-06-09</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>1894</th>
      <td>2017-06-10</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>1944</th>
      <td>2017-06-11</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>1993</th>
      <td>2017-06-12</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>2041</th>
      <td>2017-06-13</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>2088</th>
      <td>2017-06-14</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>2133</th>
      <td>2017-06-15</td>
      <td>노무현입니다</td>
      <td>9.01</td>
    </tr>
    <tr>
      <th>2177</th>
      <td>2017-06-16</td>
      <td>노무현입니다</td>
      <td>9.00</td>
    </tr>
    <tr>
      <th>2219</th>
      <td>2017-06-17</td>
      <td>노무현입니다</td>
      <td>9.00</td>
    </tr>
    <tr>
      <th>2260</th>
      <td>2017-06-18</td>
      <td>노무현입니다</td>
      <td>9.00</td>
    </tr>
    <tr>
      <th>2299</th>
      <td>2017-06-19</td>
      <td>노무현입니다</td>
      <td>8.99</td>
    </tr>
    <tr>
      <th>2340</th>
      <td>2017-06-20</td>
      <td>노무현입니다</td>
      <td>8.99</td>
    </tr>
    <tr>
      <th>2384</th>
      <td>2017-06-21</td>
      <td>노무현입니다</td>
      <td>8.99</td>
    </tr>
    <tr>
      <th>2431</th>
      <td>2017-06-22</td>
      <td>노무현입니다</td>
      <td>8.99</td>
    </tr>
    <tr>
      <th>2477</th>
      <td>2017-06-23</td>
      <td>노무현입니다</td>
      <td>8.99</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3274</th>
      <td>2017-07-10</td>
      <td>노무현입니다</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>3321</th>
      <td>2017-07-11</td>
      <td>노무현입니다</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>3371</th>
      <td>2017-07-12</td>
      <td>노무현입니다</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>3420</th>
      <td>2017-07-13</td>
      <td>노무현입니다</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>3468</th>
      <td>2017-07-14</td>
      <td>노무현입니다</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>3514</th>
      <td>2017-07-15</td>
      <td>노무현입니다</td>
      <td>8.95</td>
    </tr>
    <tr>
      <th>3560</th>
      <td>2017-07-16</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3609</th>
      <td>2017-07-17</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3657</th>
      <td>2017-07-18</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3707</th>
      <td>2017-07-19</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3760</th>
      <td>2017-07-20</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3809</th>
      <td>2017-07-21</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3859</th>
      <td>2017-07-22</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3906</th>
      <td>2017-07-23</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>3956</th>
      <td>2017-07-24</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>4006</th>
      <td>2017-07-25</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>4056</th>
      <td>2017-07-26</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>4106</th>
      <td>2017-07-27</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>4154</th>
      <td>2017-07-28</td>
      <td>노무현입니다</td>
      <td>8.94</td>
    </tr>
    <tr>
      <th>4202</th>
      <td>2017-07-29</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4251</th>
      <td>2017-07-30</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4301</th>
      <td>2017-07-31</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4354</th>
      <td>2017-08-01</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4403</th>
      <td>2017-08-02</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4453</th>
      <td>2017-08-03</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4501</th>
      <td>2017-08-04</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4549</th>
      <td>2017-08-05</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4596</th>
      <td>2017-08-06</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4642</th>
      <td>2017-08-07</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
    <tr>
      <th>4693</th>
      <td>2017-08-08</td>
      <td>노무현입니다</td>
      <td>8.93</td>
    </tr>
  </tbody>
</table>
<p>76 rows × 3 columns</p>
</div>




```python
import matplotlib.pyplot as plt
%matplotlib inline

plt.figure(figsize=(12,8))
plt.plot(tmp['date'], tmp['point'])
plt.legend(loc='best')
plt.grid()
plt.show()
```


![png](output_20_0.png)



```python
movie_best.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>point</th>
    </tr>
    <tr>
      <th>name</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>댄서</th>
      <td>914.60</td>
    </tr>
    <tr>
      <th>서서평, 천천히 평온하게</th>
      <td>889.64</td>
    </tr>
    <tr>
      <th>오두막</th>
      <td>861.65</td>
    </tr>
    <tr>
      <th>라라랜드</th>
      <td>858.89</td>
    </tr>
    <tr>
      <th>너의 이름은.</th>
      <td>738.42</td>
    </tr>
    <tr>
      <th>노무현입니다</th>
      <td>682.24</td>
    </tr>
    <tr>
      <th>보스 베이비</th>
      <td>644.21</td>
    </tr>
    <tr>
      <th>겟 아웃</th>
      <td>630.62</td>
    </tr>
    <tr>
      <th>기쿠지로의 여름</th>
      <td>613.43</td>
    </tr>
    <tr>
      <th>에이리언: 커버넌트</th>
      <td>599.67</td>
    </tr>
  </tbody>
</table>
</div>



## 영화별 날짜 변화에 따른 평점 변화 확인하기


```python
movie_pivot = pd.pivot_table(movie, index=["date"], columns=['name'], 
                                         values=['point'])
movie_pivot.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="21" halign="left">point</th>
    </tr>
    <tr>
      <th>name</th>
      <th>10분</th>
      <th>47 미터</th>
      <th>500일의 썸머</th>
      <th>7년-그들이 없는 언론</th>
      <th>7번째 내가 죽던 날</th>
      <th>7인의 사무라이</th>
      <th>8 마일</th>
      <th>가디언즈 오브 갤럭시</th>
      <th>가디언즈 오브 갤럭시 VOL. 2</th>
      <th>겟 아웃</th>
      <th>...</th>
      <th>하울의 움직이는 성</th>
      <th>하이큐!! 끝과 시작</th>
      <th>한공주</th>
      <th>해리가 샐리를 만났을 때</th>
      <th>핵소 고지</th>
      <th>행복 목욕탕</th>
      <th>헤드윅</th>
      <th>환상의 빛</th>
      <th>흑집사 : 북 오브 더 아틀란틱</th>
      <th>히든 피겨스</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-05-01</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.56</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>8.89</td>
      <td>NaN</td>
      <td>8.70</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.20</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>2017-05-02</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.56</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>8.89</td>
      <td>NaN</td>
      <td>8.68</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.21</td>
      <td>9.37</td>
    </tr>
    <tr>
      <th>2017-05-03</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.22</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>8.89</td>
      <td>NaN</td>
      <td>8.70</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.22</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>2017-05-04</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.15</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.67</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.23</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>2017-05-05</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.08</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.69</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.24</td>
      <td>9.37</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 204 columns</p>
</div>




```python
movie_pivot.columns = movie_pivot.columns.droplevel()
```


```python
movie_pivot.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>name</th>
      <th>10분</th>
      <th>47 미터</th>
      <th>500일의 썸머</th>
      <th>7년-그들이 없는 언론</th>
      <th>7번째 내가 죽던 날</th>
      <th>7인의 사무라이</th>
      <th>8 마일</th>
      <th>가디언즈 오브 갤럭시</th>
      <th>가디언즈 오브 갤럭시 VOL. 2</th>
      <th>겟 아웃</th>
      <th>...</th>
      <th>하울의 움직이는 성</th>
      <th>하이큐!! 끝과 시작</th>
      <th>한공주</th>
      <th>해리가 샐리를 만났을 때</th>
      <th>핵소 고지</th>
      <th>행복 목욕탕</th>
      <th>헤드윅</th>
      <th>환상의 빛</th>
      <th>흑집사 : 북 오브 더 아틀란틱</th>
      <th>히든 피겨스</th>
    </tr>
    <tr>
      <th>date</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-05-01</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.56</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>8.89</td>
      <td>NaN</td>
      <td>8.70</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.20</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>2017-05-02</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.56</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>8.89</td>
      <td>NaN</td>
      <td>8.68</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.21</td>
      <td>9.37</td>
    </tr>
    <tr>
      <th>2017-05-03</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.22</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>8.89</td>
      <td>NaN</td>
      <td>8.70</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.22</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>2017-05-04</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.15</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.67</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.23</td>
      <td>9.38</td>
    </tr>
    <tr>
      <th>2017-05-05</th>
      <td>8.89</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.08</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.78</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>8.69</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9.24</td>
      <td>9.37</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 204 columns</p>
</div>




```python
import platform
from matplotlib import font_manager, rc

path = "c:/Windows/Fonts/malgun.ttf"
if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system... sorry~~~~') 
```


```python
target_col = ['군함도', '노무현입니다', '택시운전사', '다크 나이트']
plt.figure(figsize=(12,6))
plt.plot(movie_pivot[target_col])
plt.legend(target_col, loc='best')
plt.grid()
plt.show()
```


![png](output_27_0.png)



```python

```
